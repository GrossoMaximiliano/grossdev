<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Incluye el autoload de Composer si usaste Composer para instalar PHPMailer
require 'vendor/autoload.php';

// Verifica si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = htmlspecialchars($_POST['nombre']);
    $email = htmlspecialchars($_POST['email']);
    $mensaje = htmlspecialchars($_POST['mensaje']);

    // Configuración de PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configuración del servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.hostinger.com'; // Reemplaza con tu servidor SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'info@grossdev.com.ar'; // Tu usuario SMTP
        $mail->Password = 'Naruliano_24'; // Tu contraseña SMTP
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Tipo de cifrado (TLS)
        $mail->Port = 465; // Puerto SMTP (587 para TLS o 465 para SSL)
        
        // Remitente y destinatarios
        $mail->setFrom('info@grossdev.com.ar', 'GrossDev'); // Remitente
        $mail->addAddress('gross.m@grossdev.com.ar'); // Primer destinatario
        $mail->addAddress('maxigrooso@gmail.com'); // Segundo destinatario

        // Contenido del correo
        $mail->isHTML(true); // Configura el correo en formato HTML
        $mail->Subject = 'Nuevo mensaje del formulario de contacto';
        $mail->Body    = "<h3>Nuevo mensaje recibido</h3>
                          <p><strong>Nombre:</strong> $nombre</p>
                          <p><strong>Email:</strong> $email</p>
                          <p><strong>Mensaje:</strong><br>$mensaje</p>";
        $mail->AltBody = "Nombre: $nombre\nEmail: $email\nMensaje:\n$mensaje";

        // Enviar el correo
        $mail->send();
        echo "Gracias por tu mensaje, te contactaremos pronto.";
    } catch (Exception $e) {
        echo "Lo sentimos, hubo un problema al enviar tu mensaje. Error: {$mail->ErrorInfo}";
    }
}
?>
